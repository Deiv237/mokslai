npm i eslint
npx eslint --init
npm i express
npm i nodemon
npm i dotenv
npm i jsonwebtoken
npm i argon2