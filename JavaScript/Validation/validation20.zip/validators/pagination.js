const { query } = require('express-validator');

const paginationValidator = [
  query('page')
    .optional()
    .isInt({ min: 1 }) //must be an integer >= 1
    .withMessage('Page must be a positive integer') //error message
    .toInt(), //convert to integer
];

module.exports = paginationValidator;
