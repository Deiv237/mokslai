import './App.css'
import CodingConfForm from './components/CodingConfForm'

function App() {

  return (
    <div className="App">
      <CodingConfForm />
    </div>
  )
}
export default App
