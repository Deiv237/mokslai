import "./Ticket.css";

const Ticket = ({ name, email, username, avatar }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-purple-900 to-black text-white p-4">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Congrats, <span className="text-orange-400">{name}</span>!</h1>
        <p className="text-xl mt-2">Your ticket is ready.</p>
        <p className="text-gray-400 mt-2">
          We've emailed your ticket to <span className="text-red-400">{email}</span> and will send updates leading up to the event.
        </p>
      </div>

      <div className="mt-6 bg-opacity-20 bg-gray-900 p-6 rounded-2xl shadow-lg max-w-lg w-full relative">
        <div className="bg-gray-800 p-4 rounded-xl flex flex-col items-center text-left">
          <div className="flex items-center space-x-4">
            {avatar && <img src={avatar} alt="Avatar" className="w-16 h-16 rounded-full border-2 border-orange-400" />}
            <div>
              <h2 className="text-xl font-semibold">Coding Conf</h2>
              <p className="text-gray-400 text-sm">Jan 31, 2025 / Austin, TX</p>
            </div>
          </div>
          <div className="mt-4 w-full bg-gray-700 h-0.5" />
          <div className="mt-4 flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {avatar && <img src={avatar} alt="User Avatar" className="w-12 h-12 rounded-full border border-gray-500" />}
              <div>
                <p className="text-lg font-semibold">{name}</p>
                <p className="text-gray-400">@{username}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ticket;
