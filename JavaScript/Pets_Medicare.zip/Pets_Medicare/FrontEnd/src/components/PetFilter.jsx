import { useState } from "react";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL;

export default function PetFilter({ setPets }) {
  const [filters, setFilters] = useState({ name: "", date: "", time: "", sortField: "date", sortOrder: "asc" });

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const applyFilter = async () => {
    try {
      const queryParams = new URLSearchParams(filters).toString();
      const response = await axios.get(`${API_URL}/pets?${queryParams}`, { withCredentials: true });

      if (response.data.status === "success") {
        setPets(response.data.data);
      }
    } catch (error) {
      console.error("Error fetching filtered pets:", error);
    }
  };

  return (
    <div className="p-4 bg-white shadow rounded-md flex gap-4">
      <input type="text" name="name" placeholder="Search Name" value={filters.name} onChange={handleChange} className="border p-2 rounded" />
      <input type="date" name="date" value={filters.date} onChange={handleChange} className="border p-2 rounded" />
      <input type="time" name="time" value={filters.time} onChange={handleChange} className="border p-2 rounded" />

      <select name="sortField" value={filters.sortField} onChange={handleChange} className="border p-2 rounded">
        <option value="name">Name</option>
        <option value="date">Date</option>
        <option value="time">Time</option>
      </select>

      <select name="sortOrder" value={filters.sortOrder} onChange={handleChange} className="border p-2 rounded">
        <option value="asc">ASC</option>
        <option value="desc">DESC</option>
      </select>

      <button onClick={applyFilter} className="bg-blue-500 text-white px-4 py-2 rounded">Apply</button>
    </div>
  );
}
